import { useState } from "react";
import { StreamingHero } from "./components/StreamingHero";
import { FavoritesSection } from "./components/FavoritesSection";
import { ContinueWatchingSection } from "./components/ContinueWatchingSection";
import { GenresSection } from "./components/GenresSection";
import { LibrarySection } from "./components/LibrarySection";
import { ImportDialog } from "./components/ImportDialog";
import { Button } from "./components/ui/button";
import { Download } from "lucide-react";

export default function App() {
  const [showImport, setShowImport] = useState(false);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm border-b border-white/10">
        <div className="px-8 py-4 flex items-center justify-between">
          <h2 className="text-white">StreamMax</h2>
          <Button
            variant="outline"
            onClick={() => setShowImport(true)}
            className="border-white/20 hover:bg-white/10"
          >
            <Download className="mr-2 h-4 w-4" />
            Import Content
          </Button>
        </div>
      </div>

      <div className="pt-16">
        <StreamingHero />
        <LibrarySection />
        <div className="px-8 py-8 space-y-12">
          <FavoritesSection />
          <ContinueWatchingSection />
          <GenresSection />
        </div>
      </div>

      <ImportDialog open={showImport} onOpenChange={setShowImport} />
    </div>
  );
}