export const config = {
  TMDB_API_KEY: "2d8ce1dafdf231d5f9ba7b869ffe22c7",
  M3U_URL: "https://xtream-ie.cc/get.php?username=5UZC15gqC&password=LxRTq2nE&type=m3u_plus",
  EPG_URL: "https://xtream-ie.cc/xmltv.php?username=5UZC15gqC&password=LxRTq2nE"
};
