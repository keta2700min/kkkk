
/**
 * safely fetches data from a URL, handling CORS and errors.
 * Returns the response object or null if failed.
 */
export async function safeFetch(url: string, options?: RequestInit): Promise<Response | null> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout

  try {
    const fetchOptions = {
      ...options,
      signal: controller.signal
    };

    // Attempt direct fetch
    const response = await fetch(url, fetchOptions);
    clearTimeout(timeoutId);

    if (response.ok) {
      return response;
    }
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    console.warn(`Direct fetch failed for ${url}: ${(error as Error).message}`);
    
    // Try proxy for network errors
    try {
      const proxyController = new AbortController();
      const proxyTimeoutId = setTimeout(() => proxyController.abort(), 15000);

      const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(url)}`;
      // We intentionally strip some headers that might trigger preflight issues on the proxy
      // or specifically, we don't want to pass 'mode: cors' if we are already doing a simple GET to a proxy.
      const { mode, signal, ...proxyOptions } = options || {};
      
      const response = await fetch(proxyUrl, {
        ...proxyOptions,
        signal: proxyController.signal
      });
      clearTimeout(proxyTimeoutId);
      return response;
    } catch (proxyError) {
      console.error(`Proxy fetch also failed for ${url}: ${(proxyError as Error).message}`);
      return null;
    }
  }
}
