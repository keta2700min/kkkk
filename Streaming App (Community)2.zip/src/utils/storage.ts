// Utility to safely save to localStorage without circular references

export function safeLocalStorageSet(key: string, data: any): boolean {
  try {
    // Test if data can be stringified
    const jsonString = JSON.stringify(data);
    localStorage.setItem(key, jsonString);
    return true;
  } catch (error) {
    console.error(`Error saving to localStorage key "${key}":`, error);
    // Clear corrupted key
    localStorage.removeItem(key);
    return false;
  }
}

export function safeLocalStorageGet<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return defaultValue;
    return JSON.parse(item) as T;
  } catch (error) {
    console.error(`Error reading from localStorage key "${key}":`, error);
    localStorage.removeItem(key);
    return defaultValue;
  }
}

export function clearLocalStorage(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error(`Error clearing localStorage key "${key}":`, error);
  }
}
