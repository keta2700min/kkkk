import { ContentCard } from "./ContentCard";

export function FavoritesSection() {
  const favorites = [
    {
      id: 1,
      title: "Buzz4K Movie Max",
      image: "https://images.unsplash.com/photo-1700174561966-36ed87c7bbeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMGNpbmVtYXRpY3xlbnwxfHx8fDE3NjM2NjY1NjN8MA&ixlib=rb-4.1.0&q=80&w=1080",
      type: "movie"
    },
    {
      id: 2,
      title: "Buzz4K Series",
      image: "https://images.unsplash.com/photo-1740430924898-39dbfc0cdd4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHBvcnRyYWl0JTIwY2luZW1hdGljfGVufDF8fHx8MTc2MzY2NjU2NHww&ixlib=rb-4.1.0&q=80&w=1080",
      type: "series"
    },
    {
      id: 3,
      title: "Buzz4K Sport",
      image: "https://images.unsplash.com/photo-1677119966332-8c6e9fb0efab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBwbGF5ZXIlMjBhY3Rpb258ZW58MXx8fHwxNzYzNjIzODE2fDA&ixlib=rb-4.1.0&q=80&w=1080",
      type: "sport"
    }
  ];

  return (
    <section>
      <h2 className="mb-6">Favoritter</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {favorites.map((item) => (
          <ContentCard
            key={item.id}
            title={item.title}
            image={item.image}
            size="large"
          />
        ))}
      </div>
    </section>
  );
}
