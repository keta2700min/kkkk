import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import { M3UImport } from "./M3UImport";
import { TMDBImport } from "./TMDBImport";
import { ClearStorage } from "./ClearStorage";

interface ImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ImportDialog({
  open,
  onOpenChange,
}: ImportDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-zinc-900 text-white border-white/10">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>Import Content</DialogTitle>
              <DialogDescription className="text-white/60">
                Import content from M3U playlists or The Movie
                Database
              </DialogDescription>
            </div>
            <ClearStorage />
          </div>
        </DialogHeader>

        <Tabs defaultValue="m3u" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-zinc-800">
            <TabsTrigger value="m3u">M3U Playlist</TabsTrigger>
            <TabsTrigger value="tmdb">TMDB API</TabsTrigger>
          </TabsList>

          <TabsContent value="m3u" className="mt-6">
            <M3UImport onClose={() => onOpenChange(false)} />
          </TabsContent>

          <TabsContent value="tmdb" className="mt-6">
            <TMDBImport onClose={() => onOpenChange(false)} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}