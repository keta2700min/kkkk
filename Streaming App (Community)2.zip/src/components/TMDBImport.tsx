import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { toast } from "sonner@2.0.3";
import { Film, Tv, Search } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { config } from "../config";
import { safeFetch } from "../utils/api";

interface TMDBImportProps {
  onClose: () => void;
}

interface TMDBResult {
  id: number;
  title?: string;
  name?: string;
  poster_path?: string;
  backdrop_path?: string;
  overview: string;
  media_type: string;
}

export function TMDBImport({ onClose }: TMDBImportProps) {
  const [apiKey, setApiKey] = useState(config.TMDB_API_KEY);
  const [searchQuery, setSearchQuery] = useState("");
  const [mediaType, setMediaType] = useState<"movie" | "tv">("movie");
  const [searchResults, setSearchResults] = useState<TMDBResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const searchTMDB = async () => {
    if (!apiKey.trim()) {
      toast.error("Please enter your TMDB API key");
      return;
    }

    if (!searchQuery.trim()) {
      toast.error("Please enter a search query");
      return;
    }

    setIsSearching(true);
    try {
      // Call the actual TMDB API
      const url = `https://api.themoviedb.org/3/search/${mediaType}?api_key=${apiKey}&query=${encodeURIComponent(searchQuery)}`;
      
      const response = await safeFetch(url);
      
      if (!response || !response.ok) {
        throw new Error("Failed to fetch from TMDB");
      }

      const data = await response.json();
      const results: TMDBResult[] = data.results.map((item: any) => ({
        id: item.id,
        title: item.title,
        name: item.name,
        poster_path: item.poster_path,
        backdrop_path: item.backdrop_path,
        overview: item.overview,
        media_type: mediaType
      }));

      setSearchResults(results);
      
      if (results.length === 0) {
        toast.info("No results found");
      } else {
        toast.success(`Found ${results.length} results`);
      }
    } catch (error) {
      toast.error("Failed to search TMDB. Please check your API key.");
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const importItem = (item: TMDBResult) => {
    // Save to localStorage - ensure clean data without circular references
    const existing = localStorage.getItem('tmdb_imports');
    const existingItems = existing ? JSON.parse(existing) : [];
    
    // Clean the item to remove any circular references
    const newItem = {
      id: item.id,
      title: item.title || item.name,
      name: item.name,
      poster_path: item.poster_path,
      backdrop_path: item.backdrop_path,
      overview: item.overview,
      media_type: item.media_type,
      imported_at: new Date().toISOString()
    };
    
    const updated = [...existingItems, newItem];
    localStorage.setItem('tmdb_imports', JSON.stringify(updated));
    
    toast.success(`Imported: ${item.title || item.name}`);
  };

  return (
    <div className="space-y-6">
      {/* API Key Input */}
      <div className="space-y-3">
        <Label htmlFor="tmdb-key">TMDB API Key</Label>
        <Input
          id="tmdb-key"
          type="password"
          placeholder="Enter your TMDB API key"
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
          className="bg-zinc-800 border-white/10"
        />
        <p className="text-white/40">
          Get your free API key from{" "}
          <a 
            href="https://www.themoviedb.org/settings/api" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-400 hover:underline"
          >
            themoviedb.org
          </a>
        </p>
      </div>

      {/* Search Section */}
      <div className="space-y-3">
        <Label htmlFor="search">Search Content</Label>
        <div className="flex gap-2">
          <Select value={mediaType} onValueChange={(value: "movie" | "tv") => setMediaType(value)}>
            <SelectTrigger className="w-32 bg-zinc-800 border-white/10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-zinc-800 border-white/10">
              <SelectItem value="movie">
                <div className="flex items-center">
                  <Film className="mr-2 h-4 w-4" />
                  Movies
                </div>
              </SelectItem>
              <SelectItem value="tv">
                <div className="flex items-center">
                  <Tv className="mr-2 h-4 w-4" />
                  TV Shows
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
          <Input
            id="search"
            placeholder="Search for movies or TV shows..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && searchTMDB()}
            className="bg-zinc-800 border-white/10"
          />
          <Button
            onClick={searchTMDB}
            disabled={isSearching}
            className="bg-white text-black hover:bg-white/90"
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="space-y-3">
          <Label>Search Results</Label>
          <div className="max-h-96 overflow-y-auto space-y-3 pr-2">
            {searchResults.map((item) => (
              <div
                key={item.id}
                className="flex gap-4 p-3 rounded-lg bg-zinc-800/50 border border-white/10"
              >
                <div className="w-20 h-28 bg-zinc-700 rounded overflow-hidden flex-shrink-0">
                  {item.poster_path && (
                    <ImageWithFallback
                      src={`https://image.tmdb.org/t/p/w200${item.poster_path}`}
                      alt={item.title || item.name || ""}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="mb-1">{item.title || item.name}</h4>
                  <p className="text-white/60 line-clamp-2 mb-2">
                    {item.overview}
                  </p>
                  <Button
                    size="sm"
                    onClick={() => importItem(item)}
                    className="bg-white text-black hover:bg-white/90"
                  >
                    Import
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-zinc-800/50 border border-white/10 rounded-lg p-4">
        <p className="text-white/60">
          <strong>Note:</strong> This is a demo implementation. In production, this would connect to the real TMDB API to fetch movie and TV show metadata, posters, and other information.
        </p>
      </div>
    </div>
  );
}