import { useState } from "react";
import { Play, Star, Info } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { VideoPlayer } from "./VideoPlayer";

interface MediaItem {
  id: string;
  title: string;
  image: string;
  type: "movie" | "series" | "live";
  streamUrl?: string;
  year?: string;
  rating?: number;
  overview?: string;
  tmdbId?: number;
  season?: number;
  episode?: number;
}

interface MediaCardProps {
  item: MediaItem;
}

export function MediaCard({ item }: MediaCardProps) {
  const [showPlayer, setShowPlayer] = useState(false);

  const handleClick = () => {
    if (item.streamUrl || item.tmdbId) {
      setShowPlayer(true);
    }
  };

  return (
    <>
      <div 
        className="group relative cursor-pointer overflow-hidden rounded-lg transition-all duration-300 hover:scale-105 hover:z-10"
        onClick={handleClick}
      >
        <div className="relative aspect-[2/3] w-full bg-zinc-800">
          {item.image ? (
            <ImageWithFallback
              src={item.image}
              alt={item.title}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="h-full w-full flex items-center justify-center text-white/40">
              <span className="text-center p-4 text-sm">{item.title}</span>
            </div>
          )}
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Rating badge */}
          {item.rating && (
            <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/80 backdrop-blur-sm rounded-full px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
              <span className="text-white text-xs">{item.rating.toFixed(1)}</span>
            </div>
          )}

          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="rounded-full bg-white/90 backdrop-blur-sm p-3 transform scale-0 group-hover:scale-100 transition-transform duration-300">
              <Play className="h-6 w-6 fill-black text-black" />
            </div>
          </div>

          {/* Info at bottom */}
          <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <h4 className="text-white text-sm mb-1 line-clamp-2">{item.title}</h4>
            {item.year && (
              <p className="text-white/70 text-xs">{item.year}</p>
            )}
          </div>
        </div>
      </div>

      <VideoPlayer
        open={showPlayer}
        onOpenChange={setShowPlayer}
        title={item.title}
        videoUrl={item.streamUrl}
        tmdbId={item.tmdbId}
        mediaType={item.type === 'live' ? undefined : item.type}
        season={item.season}
        episode={item.episode}
      />
    </>
  );
}