import { ContentCard } from "./ContentCard";

export function ContinueWatchingSection() {
  const continueWatching = [
    {
      id: 1,
      title: "Movie Title",
      image: "https://images.unsplash.com/photo-1740430924898-39dbfc0cdd4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHBvcnRyYWl0JTIwY2luZW1hdGljfGVufDF8fHx8MTc2MzY2NjU2NHww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 2,
      title: "Movie Title",
      image: "https://images.unsplash.com/photo-1758525589346-59d1e527c574?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXRlY3RpdmUlMjBoYXQlMjB2aW50YWdlfGVufDF8fHx8MTc2MzY2NjU2NXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 3,
      title: "Movie Title",
      image: "https://images.unsplash.com/photo-1700174561966-36ed87c7bbeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMGNpbmVtYXRpY3xlbnwxfHx8fDE3NjM2NjY1NjN8MA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 4,
      title: "Movie",
      image: "https://images.unsplash.com/photo-1638996030249-abc99a735463?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHBlcnNvbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2MzY2NjU2NXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 5,
      title: "Nyheder",
      image: "https://images.unsplash.com/photo-1625502709763-f5f3880c17ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW4lMjBzdWl0JTIwcG9ydHJhaXR8ZW58MXx8fHx8MTc2MzY2NjU2NXww&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  return (
    <section>
      <div className="flex items-center justify-between mb-6">
        <h2>Fortsæt hvor du slap</h2>
        <p className="text-white/60">Nuistil fortsæt</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {continueWatching.map((item) => (
          <ContentCard
            key={item.id}
            title={item.title}
            image={item.image}
            size="small"
          />
        ))}
      </div>
    </section>
  );
}
