import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Search, RefreshCw } from "lucide-react";
import { MediaCard } from "./MediaCard";
import { config } from "../config";
import { toast } from "sonner@2.0.3";
import { safeFetch } from "../utils/api";

interface MediaItem {
  id: string;
  tmdbId?: number;
  title: string;
  image: string;
  type: "movie" | "series" | "live";
  streamUrl?: string;
  year?: string;
  rating?: number;
  overview?: string;
  genres?: string[];
  season?: number;
  episode?: number;
}

interface GenreSection {
  name: string;
  items: MediaItem[];
}

export function LibrarySection() {
  const [genreSections, setGenreSections] = useState<GenreSection[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    loadLibrary();
  }, []);

  const loadLibrary = async (forceRefresh = false) => {
    setIsLoading(true);
    try {
      // Try to load from cache first if not forced
      if (!forceRefresh) {
        const cachedLibrary = localStorage.getItem('library_cache');
        if (cachedLibrary) {
          try {
            const { timestamp, sections } = JSON.parse(cachedLibrary);
            // Cache valid for 24 hours
            if (Date.now() - timestamp < 24 * 60 * 60 * 1000 && sections.length > 0) {
              console.log("Loaded library from cache");
              setGenreSections(sections);
              setIsLoading(false);
              return;
            }
          } catch (e) {
            console.error("Error parsing cache", e);
          }
        }
      }

      const channelsData = localStorage.getItem('m3u_channels');
      console.log("Loading library, found data:", !!channelsData);
      
      if (channelsData) {
        const parsedChannels = JSON.parse(channelsData);
        console.log("Parsed channels count:", parsedChannels.length);
        
        if (Array.isArray(parsedChannels) && parsedChannels.length > 0) {
          await categorizeAndEnrichChannels(parsedChannels);
        } else {
          setGenreSections([]);
        }
      } else {
        console.log("No channels found in storage");
        setGenreSections([]);
      }
    } catch (error) {
      console.error("Error loading library:", error);
      toast.error("Failed to load library");
      setGenreSections([]);
    } finally {
      setIsLoading(false);
    }
  };

  const categorizeAndEnrichChannels = async (channels: any[]) => {
    const allItems: MediaItem[] = [];
    
    console.log("Starting to process channels with TMDB...");
    
    // Process channels in batches to avoid rate limiting
    // Limit to first 50 channels for performance in this demo
    const limit = 50;
    const channelsToProcess = channels.slice(0, limit);
    
    for (let i = 0; i < channelsToProcess.length; i++) {
      const channel = channelsToProcess[i];
      const originalName = String(channel.name || '');
      
      // Extract season and episode before cleaning
      const seMatch = originalName.match(/S(\d+)\s*E(\d+)/i);
      const season = seMatch ? parseInt(seMatch[1]) : 1;
      const episode = seMatch ? parseInt(seMatch[2]) : 1;
      
      const cleanName = cleanChannelName(originalName);
      const cleanGroup = String(channel.group || '');
      const cleanUrl = String(channel.url || '');
      const cleanLogo = channel.logo ? String(channel.logo) : '';
      
      const category = detectCategory(cleanGroup, cleanName, cleanUrl);
      
        // Add delay to avoid rate limiting
        if (i > 0) {
          await new Promise(resolve => setTimeout(resolve, 200));
        }

      if (category === "movie" || category === "series") {
        const tmdbData = await searchTMDB(cleanName, category === "movie" ? "movie" : "tv");
        
        if (tmdbData) {
          allItems.push({
            id: `${category}-${i}-${Date.now()}-${Math.random()}`,
            tmdbId: tmdbData.id,
            season: category === 'series' ? season : undefined,
            episode: category === 'series' ? episode : undefined,
            title: tmdbData.title || cleanName,
            image: tmdbData.poster || cleanLogo,
            type: category,
            streamUrl: cleanUrl,
            year: tmdbData.year,
            rating: tmdbData.rating,
            overview: tmdbData.overview,
            genres: tmdbData.genres || []
          });
        } else {
          // No TMDB match, still add it
          allItems.push({
            id: `${category}-${i}-${Date.now()}-${Math.random()}`,
            title: cleanName,
            image: cleanLogo,
            type: category,
            streamUrl: cleanUrl,
            genres: [cleanGroup || 'Other']
          });
        }
      } else {
        // Live TV
        allItems.push({
          id: `live-${i}-${Date.now()}-${Math.random()}`,
          title: cleanName,
          image: cleanLogo,
          type: "live",
          streamUrl: cleanUrl,
          genres: ['Live TV']
        });
      }
    }

    // Group by genres
    const genreMap = new Map<string, MediaItem[]>();
    
    allItems.forEach(item => {
      const itemGenres = item.genres && item.genres.length > 0 ? item.genres : ['Other'];
      
      itemGenres.forEach(genre => {
        if (!genreMap.has(genre)) {
          genreMap.set(genre, []);
        }
        genreMap.get(genre)!.push(item);
      });
    });

    // Convert to array and sort by popularity
    const sections: GenreSection[] = Array.from(genreMap.entries())
      .map(([name, items]) => ({ name, items }))
      .sort((a, b) => b.items.length - a.items.length);

    setGenreSections(sections);
    
    // Save to cache
    try {
      localStorage.setItem('library_cache', JSON.stringify({
        timestamp: Date.now(),
        sections
      }));
    } catch (e) {
      console.error("Failed to save library cache:", e);
    }
    
    toast.success(`✅ Loaded ${allItems.length} items organized by genre!`);
  };

  const cleanChannelName = (name: string): string => {
    return name
      .replace(/^(VOD|MOVIE|SERIES|TV|4K|HD|FHD|UHD)[\s:-]*/i, "")
      .replace(/\s*\[(.*?)\]\s*/g, "")
      .replace(/\s*\((.*?)\)\s*$/g, "")
      .replace(/\s*[-]?\s*S\d+\s*E\d+.*$/i, "")
      .trim();
  };

  const detectCategory = (group: string, name: string, url: string): "movie" | "series" | "live" => {
    const groupLower = group.toLowerCase();
    const nameLower = name.toLowerCase();
    const urlLower = url.toLowerCase();

    // Series detection
    if (groupLower.includes("series") || groupLower.includes("show") || 
        nameLower.match(/s\d+\s*e\d+/i) || groupLower.includes("tv show") ||
        urlLower.includes("/series/")) {
      return "series";
    }

    // Movie detection
    const movieGenres = [
      "horror", "action", "comedy", "drama", "thriller", "adventure", 
      "scifi", "sci-fi", "fantasy", "romance", "documentary", 
      "family", "animation", "mystery", "crime"
    ];

    if (groupLower.includes("movie") || groupLower.includes("film") || 
        nameLower.includes("movie") || groupLower.includes("vod") ||
        urlLower.includes("/movie/") ||
        movieGenres.some(g => groupLower.includes(g))) {
      return "movie";
    }

    return "live";
  };

  const searchTMDB = async (query: string, type: "movie" | "tv"): Promise<any> => {
    try {
      const url = `https://api.themoviedb.org/3/search/${type}?api_key=${config.TMDB_API_KEY}&query=${encodeURIComponent(query)}`;
      const response = await safeFetch(url);

      if (!response || !response.ok) return null;

      const data = await response.json();
      if (data.results && data.results.length > 0) {
        const result = data.results[0];
        
        // Get genre names
        let genres: string[] = [];
        if (result.genre_ids && result.genre_ids.length > 0) {
          genres = await getGenreNames(result.genre_ids, type);
        }
        
        return {
          id: result.id,
          title: result.title || result.name,
          poster: result.poster_path 
            ? `https://image.tmdb.org/t/p/w500${result.poster_path}` 
            : null,
          year: (result.release_date || result.first_air_date || "").substring(0, 4),
          rating: result.vote_average,
          overview: result.overview,
          genres: genres
        };
      }
    } catch (error) {
      console.error("TMDB search error:", error);
    }
    return null;
  };

  const getGenreNames = async (genreIds: number[], type: "movie" | "tv"): Promise<string[]> => {
    const genreMap: { [key: number]: string } = {
      // Movie genres
      28: "Action",
      12: "Adventure",
      16: "Animation",
      35: "Comedy",
      80: "Crime",
      99: "Documentary",
      18: "Drama",
      10751: "Family",
      14: "Fantasy",
      36: "History",
      27: "Horror",
      10402: "Music",
      9648: "Mystery",
      10749: "Romance",
      878: "Science Fiction",
      10770: "TV Movie",
      53: "Thriller",
      10752: "War",
      37: "Western",
      // TV genres
      10759: "Action & Adventure",
      10762: "Kids",
      10763: "News",
      10764: "Reality",
      10765: "Sci-Fi & Fantasy",
      10766: "Soap",
      10767: "Talk",
      10768: "War & Politics"
    };

    return genreIds.map(id => genreMap[id] || "Other").filter(Boolean);
  };

  const filterSections = (sections: GenreSection[]) => {
    if (!searchQuery) return sections;
    
    return sections
      .map(section => ({
        ...section,
        items: section.items.filter(item =>
          item.title.toLowerCase().includes(searchQuery.toLowerCase())
        )
      }))
      .filter(section => section.items.length > 0);
  };

  return (
    <section className="py-8">
      <div className="px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-white">Browse by Genre</h2>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <Input
                placeholder="Search library..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-800 border-white/10 w-64"
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => loadLibrary(true)}
              disabled={isLoading}
              className="border-white/20 hover:bg-white/10"
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-8">
            {[...Array(3)].map((_, i) => (
              <div key={i}>
                <div className="h-8 w-48 bg-zinc-800 rounded mb-4 animate-pulse" />
                <div className="flex gap-4 overflow-hidden">
                  {[...Array(6)].map((_, j) => (
                    <div key={j} className="aspect-[2/3] w-48 bg-zinc-800 rounded-lg animate-pulse flex-shrink-0" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : filterSections(genreSections).length > 0 ? (
          <div className="space-y-10">
            {filterSections(genreSections).map((section, idx) => (
              <div key={idx}>
                <h3 className="text-white mb-4">{section.name}</h3>
                <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                  {section.items.map((item) => (
                    <div key={item.id} className="w-48 flex-shrink-0">
                      <MediaCard item={item} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 text-white/60">
            <p className="mb-2">No content found.</p>
            <p>Click "Import Content" to add your M3U playlist.</p>
          </div>
        )}
      </div>
    </section>
  );
}