import { useState } from "react";
import { Play } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { VideoPlayer } from "./VideoPlayer";

interface ContentCardProps {
  title: string;
  image: string;
  size?: "small" | "medium" | "large";
  videoUrl?: string;
}

export function ContentCard({ title, image, size = "medium", videoUrl }: ContentCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);

  const sizeClasses = {
    small: "aspect-[2/3]",
    medium: "aspect-[2/3]",
    large: "aspect-[16/9]"
  };

  const handlePlayClick = () => {
    setShowPlayer(true);
  };

  return (
    <>
      <div 
        className="group relative cursor-pointer overflow-hidden rounded-lg transition-transform duration-300 hover:scale-105"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className={`relative ${sizeClasses[size]} w-full`}>
          <ImageWithFallback
            src={image}
            alt={title}
            className="h-full w-full object-cover"
          />
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute inset-0 flex items-center justify-center">
              <button
                onClick={handlePlayClick}
                className="rounded-full bg-white/20 backdrop-blur-sm p-4 transform scale-0 group-hover:scale-100 transition-transform duration-300 hover:bg-white/30"
              >
                <Play className="h-8 w-8 fill-white text-white" />
              </button>
            </div>
          </div>

          {/* Title */}
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="text-white drop-shadow-lg">{title}</h3>
          </div>
        </div>
      </div>

      <VideoPlayer
        open={showPlayer}
        onOpenChange={setShowPlayer}
        title={title}
        videoUrl={videoUrl}
      />
    </>
  );
}