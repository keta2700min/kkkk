import { Button } from "./ui/button";
import { Trash2 } from "lucide-react";
import { toast } from "sonner@2.0.3";

export function ClearStorage() {
  const clearAllStorage = () => {
    try {
      localStorage.clear();
      toast.success("All storage cleared. Please refresh and re-import.");
    } catch (error) {
      console.error("Error clearing storage:", error);
      toast.error("Failed to clear storage");
    }
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={clearAllStorage}
      className="border-red-500/20 text-red-500 hover:bg-red-500/10"
    >
      <Trash2 className="mr-2 h-4 w-4" />
      Clear All Data
    </Button>
  );
}
