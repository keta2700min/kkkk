import { useState, useEffect } from "react";
import { Play, Monitor, Heart, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { motion, AnimatePresence } from "motion/react";
import { VideoPlayer } from "./VideoPlayer";

const featuredContent = [
  {
    id: 1,
    title: "Buzz4K Movie Max",
    subtitle: "Now: Movie Title",
    next: "Next: Another Movie Title",
    image: "https://images.unsplash.com/photo-1700174561966-36ed87c7bbeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMGNpbmVtYXRpY3xlbnwxfHx8fDE3NjM2NjY1NjN8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 2,
    title: "Buzz4K Series",
    subtitle: "Season 3 - Episode 5",
    next: "Next: Episode 6",
    image: "https://images.unsplash.com/photo-1740430924898-39dbfc0cdd4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHBvcnRyYWl0JTIwY2luZW1hdGljfGVufDF8fHx8MTc2MzY2NjU2NHww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 3,
    title: "Buzz4K Sport",
    subtitle: "Live: Premier League",
    next: "Next: Champions League",
    image: "https://images.unsplash.com/photo-1677119966332-8c6e9fb0efab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBwbGF5ZXIlMjBhY3Rpb258ZW58MXx8fHwxNzYzNjIzODE2fDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 4,
    title: "Buzz4K Cinema",
    subtitle: "Thriller Night",
    next: "Next: Mystery Hour",
    image: "https://images.unsplash.com/photo-1758525589346-59d1e527c574?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXRlY3RpdmUlMjBoYXQlMjB2aW50YWdlfGVufDF8fHx8MTc2MzY2NjU2NXww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 5,
    title: "Buzz4K Drama",
    subtitle: "Award Winning Series",
    next: "Next: Season Finale",
    image: "https://images.unsplash.com/photo-1625502709763-f5f3880c17ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW4lMjBzdWl0JTIwcG9ydHJhaXR8ZW58MXx8fHwxNzYzNjY2NTY1fDA&ixlib=rb-4.1.0&q=80&w=1080"
  }
];

export function StreamingHero() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [showPlayer, setShowPlayer] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      nextSlide();
    }, 5000);

    return () => clearInterval(timer);
  }, [currentIndex]);

  const nextSlide = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % featuredContent.length);
  };

  const prevSlide = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + featuredContent.length) % featuredContent.length);
  };

  const goToSlide = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const handlePlay = () => {
    // Get imported channels from localStorage
    const channels = localStorage.getItem('m3u_channels');
    if (channels) {
      const parsedChannels = JSON.parse(channels);
      if (parsedChannels.length > 0) {
        // You could map current slide to a channel or just play first one
        setShowPlayer(true);
      } else {
        setShowPlayer(true);
      }
    } else {
      setShowPlayer(true);
    }
  };

  const currentContent = featuredContent[currentIndex];

  return (
    <>
      <div className="relative h-[600px] w-full overflow-hidden">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
            className="absolute inset-0"
          >
            {/* Background Image */}
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${currentContent.image})` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            </div>

            {/* Content */}
            <div className="relative h-full flex flex-col justify-end px-8 pb-16">
              <div className="max-w-2xl">
                <motion.h1 
                  className="mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  {currentContent.title}
                </motion.h1>
                <motion.p 
                  className="mb-2"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  {currentContent.subtitle}
                </motion.p>
                <motion.p 
                  className="mb-6 text-white/80"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  {currentContent.next}
                </motion.p>
                
                <motion.div 
                  className="flex items-center gap-3"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <Button 
                    className="bg-white text-black hover:bg-white/90"
                    onClick={handlePlay}
                  >
                    <Play className="mr-2 h-5 w-5 fill-current" />
                    Afspil
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="bg-black/50 border-white/20 hover:bg-white/10"
                  >
                    <Monitor className="h-5 w-5" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="bg-black/50 border-white/20 hover:bg-white/10"
                  >
                    <Heart className="h-5 w-5" />
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Navigation Arrows */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white backdrop-blur-sm"
          onClick={prevSlide}
        >
          <ChevronLeft className="h-8 w-8" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white backdrop-blur-sm"
          onClick={nextSlide}
        >
          <ChevronRight className="h-8 w-8" />
        </Button>

        {/* Dots Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex gap-2">
          {featuredContent.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'w-8 bg-white' 
                  : 'w-2 bg-white/50 hover:bg-white/75'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
      <VideoPlayer
        open={showPlayer}
        onOpenChange={setShowPlayer}
        title={currentContent.title}
      />
    </>
  );
}