import { useState, useRef, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  X,
  Globe,
  FileVideo,
} from "lucide-react";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import Hls from "hls.js";

interface VideoPlayerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  videoUrl?: string;
  title?: string;
  tmdbId?: number;
  mediaType?: "movie" | "series";
  season?: number;
  episode?: number;
}

export function VideoPlayer({
  open,
  onOpenChange,
  videoUrl,
  title,
  tmdbId,
  mediaType,
  season,
  episode,
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [useProxy, setUseProxy] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [useEmbed, setUseEmbed] = useState(false);

  // Reset proxy state and retry count when url changes
  useEffect(() => {
    setUseProxy(false);
    setRetryCount(0);
  }, [videoUrl]);

  // Initialize useEmbed based on available props
  useEffect(() => {
    if (open) {
      // Default to embed if tmdbId is present (as requested for TMDB imports)
      // But allows fallback if needed
      setUseEmbed(!!tmdbId);
    }
  }, [open, tmdbId]);

  const safePlay = async () => {
    if (videoRef.current) {
      try {
        await videoRef.current.play();
      } catch (error) {
        // Ignore AbortError which happens if pause is called while play is pending
        if ((error as Error).name !== "AbortError") {
          console.error("Video playback error:", error);
        }
      }
    }
  };

  useEffect(() => {
    // If using embed, skip HLS setup
    if (useEmbed) return;

    let hls: Hls | null = null;

    if (open && videoRef.current && videoUrl) {
      const isHls =
        videoUrl.toLowerCase().includes(".m3u8") ||
        videoUrl.toLowerCase().includes(".m3u");

      if (Hls.isSupported() && isHls) {
        hls = new Hls({
          enableWorker: false, // Disable worker to prevent fetch errors in restricted environments
          lowLatencyMode: true,
          // Prevent throwing on XHR errors
          xhrSetup: (xhr, url) => {
            if (useProxy) {
              if (!url.includes("corsproxy.io")) {
                // When re-opening, we must respect the expected response type
                const responseType = xhr.responseType;
                const withCredentials = xhr.withCredentials;

                xhr.open(
                  "GET",
                  `https://corsproxy.io/?${encodeURIComponent(url)}`,
                  true,
                );

                // Restore critical properties that might be lost on re-open
                if (responseType)
                  xhr.responseType = responseType;
                if (withCredentials)
                  xhr.withCredentials = withCredentials;
              }
            }
          },
        });

        // Use the proxy URL for the initial load if we are already in proxy mode
        // (Though xhrSetup handles it, loadSource expects the logical URL usually)
        hls.loadSource(videoUrl);
        hls.attachMedia(videoRef.current);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          safePlay();
        });

        hls.on(Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                console.warn(
                  "Network error encountered, trying to recover...",
                );
                if (!useProxy) {
                  console.log("Switching to proxy mode...");
                  setUseProxy(true);
                  // HLS instance will be destroyed by cleanup when effect re-runs
                } else if (retryCount < 3) {
                  console.log(
                    `Retrying connection (${retryCount + 1}/3)...`,
                  );
                  setRetryCount((prev) => prev + 1);
                  hls?.startLoad();
                } else {
                  console.error(
                    "Max retries reached. Giving up.",
                  );
                  hls?.destroy();
                }
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                console.error(
                  "fatal media error encountered, try to recover",
                );
                hls?.recoverMediaError();
                break;
              default:
                hls?.destroy();
                break;
            }
          }
        });
      } else if (
        videoRef.current.canPlayType(
          "application/vnd.apple.mpegurl",
        )
      ) {
        // Native HLS support (Safari)
        videoRef.current.src = videoUrl;
        safePlay();
      } else {
        // Standard video
        if (useProxy) {
          videoRef.current.src = `https://corsproxy.io/?${encodeURIComponent(videoUrl)}`;
        } else {
          videoRef.current.src = videoUrl;
        }
        safePlay();
      }
    } else if (!open && videoRef.current) {
      videoRef.current.pause();
      videoRef.current.removeAttribute("src");
      if (hls) hls.destroy();
    }

    return () => {
      if (hls) hls.destroy();
    };
  }, [open, videoUrl, useProxy, retryCount, useEmbed]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        safePlay();
      } else {
        videoRef.current.pause();
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setIsMuted(newVolume === 0);
    }
  };

  const toggleFullscreen = async () => {
    if (videoRef.current) {
      try {
        if (document.fullscreenElement) {
          await document.exitFullscreen();
        } else {
          await videoRef.current.requestFullscreen();
        }
      } catch (error) {
        console.error("Fullscreen toggle failed:", error);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl p-0 bg-black border-none">
        <VisuallyHidden>
          <DialogTitle>{title || "Video Player"}</DialogTitle>
          <DialogDescription>
            Video player for streaming content
          </DialogDescription>
        </VisuallyHidden>

        <div className="relative aspect-video bg-black group">
          {/* Source Switcher - Only show if we have both sources */}
          {(tmdbId && videoUrl) && (
             <Button
               variant="secondary"
               size="sm"
               className="absolute top-4 left-4 z-50 bg-black/50 hover:bg-black/80 text-white backdrop-blur-sm gap-2 border border-white/10"
               onClick={() => setUseEmbed(!useEmbed)}
             >
               {useEmbed ? <FileVideo className="h-4 w-4" /> : <Globe className="h-4 w-4" />}
               {useEmbed ? "Switch to Direct" : "Switch to Cloud"}
             </Button>
          )}

          {useEmbed && tmdbId ? (
            <div className="w-full h-full relative">
               <iframe
                 src={mediaType === 'series' 
                   ? `https://player.videasy.net/tv/${tmdbId}/${season || 1}/${episode || 1}`
                   : `https://player.videasy.net/movie/${tmdbId}`
                 }
                 className="w-full h-full border-none rounded-[6px]" // slightly less rounded than video for iframe
                 allowFullScreen
                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
               />
                {/* Close button for iframe mode */}
               <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onOpenChange(false)}
                  className="absolute top-4 right-4 z-50 text-white bg-black/50 hover:bg-black/80 rounded-full hover:bg-white/20"
                >
                  <X className="h-6 w-6" />
                </Button>
            </div>
          ) : videoUrl ? (
            <>
              <video
                ref={videoRef}
                className="w-full h-full bg-black rounded-[6px]"
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onError={(e) => {
                  console.error("Video error:", e);
                  if (!useProxy) setUseProxy(true);
                }}
                onClick={togglePlay}
                playsInline
                crossOrigin="anonymous"
              >
                Your browser does not support the video tag.
              </video>

              {/* Controls Overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-6">
                {title && (
                  <h3 className="text-white mb-4">{title}</h3>
                )}

                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={togglePlay}
                    className="text-white hover:bg-white/20"
                  >
                    {isPlaying ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6 fill-current" />
                    )}
                  </Button>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={toggleMute}
                      className="text-white hover:bg-white/20"
                    >
                      {isMuted ? (
                        <VolumeX className="h-5 w-5" />
                      ) : (
                        <Volume2 className="h-5 w-5" />
                      )}
                    </Button>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={volume}
                      onChange={handleVolumeChange}
                      className="w-24 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="flex-1" />

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleFullscreen}
                    className="text-white hover:bg-white/20"
                  >
                    <Maximize className="h-5 w-5" />
                  </Button>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onOpenChange(false)}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-white/60">
                <p className="mb-4">
                  No video source available
                </p>
                <p>
                  Please import content from M3U or TMDB first
                </p>
                <Button
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  className="mt-4"
                >
                  Close Player
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}