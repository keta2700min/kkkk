import { ContentCard } from "./ContentCard";

export function GenresSection() {
  const genres = [
    {
      id: 1,
      title: "Film",
      image: "https://images.unsplash.com/photo-1669670617710-51c60ceb56b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9uZGUlMjB3b21hbiUyMG1vdmllfGVufDF8fHx8MTc2MzY2NjU2NXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 2,
      title: "Series",
      image: "https://images.unsplash.com/photo-1740430924898-39dbfc0cdd4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHBvcnRyYWl0JTIwY2luZW1hdGljfGVufDF8fHx8MTc2MzY2NjU2NHww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 3,
      title: "Sport",
      image: "https://images.unsplash.com/photo-1650805174015-53ceeec12c40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydHMlMjBhY3Rpb258ZW58MXx8fHwxNzYzNjIzNDkzfDA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: 4,
      title: "Nyheder",
      image: "https://images.unsplash.com/photo-1580171401298-4c2c0c44cc43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXdzJTIwYW5jaG9yfGVufDF8fHx8MTc2MzY2NjU2N3ww&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  return (
    <section>
      <h2 className="mb-6">Genrer</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {genres.map((item) => (
          <ContentCard
            key={item.id}
            title={item.title}
            image={item.image}
            size="medium"
          />
        ))}
      </div>
    </section>
  );
}
