import { useState } from "react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { toast } from "sonner@2.0.3";
import { Upload, Link, Download, FileText } from "lucide-react";
import { config } from "../config";
import { safeFetch } from "../utils/api";

interface M3UImportProps {
  onClose: () => void;
}

interface M3UChannel {
  name: string;
  url: string;
  logo?: string;
  group?: string;
}

export function M3UImport({ onClose }: M3UImportProps) {
  const [m3uUrl, setM3uUrl] = useState(config.M3U_URL);
  const [m3uText, setM3uText] = useState("");
  const [isImporting, setIsImporting] = useState(false);

  const parseM3U = (content: string): M3UChannel[] => {
    const lines = content.split('\n');
    const channels: M3UChannel[] = [];
    let currentChannel: Partial<M3UChannel> = {};

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (line.startsWith('#EXTINF:')) {
        // Parse channel info
        const nameMatch = line.match(/,(.+)$/);
        const logoMatch = line.match(/tvg-logo="([^"]+)"/);
        const groupMatch = line.match(/group-title="([^"]+)"/);
        
        currentChannel = {
          name: nameMatch ? nameMatch[1].trim() : 'Unknown Channel',
          logo: logoMatch ? logoMatch[1] : undefined,
          group: groupMatch ? groupMatch[1] : 'Uncategorized'
        };
      } else if (line && !line.startsWith('#') && currentChannel.name) {
        // This is the stream URL
        currentChannel.url = line;
        channels.push({
          name: currentChannel.name,
          url: currentChannel.url,
          logo: currentChannel.logo,
          group: currentChannel.group
        } as M3UChannel);
        currentChannel = {};
      }
    }

    return channels;
  };

  const handleImportFromUrl = async () => {
    if (!m3uUrl.trim()) {
      toast.error("Please enter a valid M3U URL");
      return;
    }

    setIsImporting(true);
    
    try {
      console.log("Fetching M3U from:", m3uUrl);
      
      // Removed explicit mode: 'cors' to let safeFetch handle it
      const response = await safeFetch(m3uUrl, {
        headers: {
          'Accept': 'application/x-mpegurl, audio/mpegurl, audio/x-mpegurl, text/plain, */*'
        }
      });
      
      if (!response || !response.ok) {
        throw new Error(`HTTP error! status: ${response?.status}`);
      }

      const content = await response.text();
      console.log("Fetched content length:", content.length);
      
      if (!content || content.length < 10) {
        throw new Error("Empty or invalid M3U content");
      }
      
      const channels = parseM3U(content);
      console.log("Parsed channels:", channels.length);
      
      if (channels.length === 0) {
        toast.error("No valid channels found in M3U. Check the URL format.");
        setIsImporting(false);
        return;
      }

      saveChannels(channels);
      toast.success(`✅ Successfully imported ${channels.length} channels!`);
      
      // Reload the page to show new content
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } catch (error: any) {
      console.error("M3U import error:", error);
      toast.error(`Import failed: ${error.message}. Try pasting content directly.`);
      setIsImporting(false);
    }
  };

  const handleImportFromText = () => {
    if (!m3uText.trim()) {
      toast.error("Please paste M3U playlist content");
      return;
    }

    setIsImporting(true);
    try {
      console.log("Parsing pasted M3U content...");
      const channels = parseM3U(m3uText);
      console.log("Parsed channels:", channels.length);
      
      if (channels.length === 0) {
        toast.error("No valid channels found in M3U content");
        setIsImporting(false);
        return;
      }

      saveChannels(channels);
      toast.success(`✅ Successfully imported ${channels.length} channels!`);
      
      // Reload the page to show new content
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } catch (error: any) {
      console.error("M3U parse error:", error);
      toast.error(`Parse failed: ${error.message}`);
      setIsImporting(false);
    }
  };

  const saveChannels = (channels: M3UChannel[]) => {
    try {
      // Create clean plain objects
      const cleanChannels = channels.map(channel => ({
        name: String(channel.name || 'Unknown'),
        url: String(channel.url || ''),
        logo: channel.logo ? String(channel.logo) : undefined,
        group: channel.group ? String(channel.group) : undefined
      }));
      
      console.log("Saving channels to localStorage:", cleanChannels.length);
      
      // Clear old data and save new
      localStorage.removeItem('m3u_channels');
      const jsonData = JSON.stringify(cleanChannels);
      localStorage.setItem('m3u_channels', jsonData);
      
      console.log("Channels saved successfully!");
    } catch (error: any) {
      console.error('Error saving channels:', error);
      toast.error('Failed to save channels');
      throw error;
    }
  };

  const downloadM3U = async () => {
    try {
      const response = await safeFetch(m3uUrl);
      if (!response || !response.ok) throw new Error("Failed to fetch");
      
      const content = await response.text();
      const blob = new Blob([content], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'playlist.m3u';
      a.click();
      toast.success("M3U downloaded! You can paste its content below.");
    } catch (error) {
      toast.error("Failed to download M3U");
    }
  };

  const handleLoadSample = () => {
    const sampleData = `#EXTM3U
#EXTINF:0 CUID="9647" tvg-name="5 Years After the Fall (2016)" tvg-logo="https://image.tmdb.org/t/p/w600_and_h900_bestv2/nBPziRVCGxaD5UooIaXUGbYmeZC.jpg" group-title="Horror ",5 Years After the Fall (2016)
http://1tv41.icu:8080/movie/36471153/36471153/204404.mp4
#EXTINF:0 CUID="9648" tvg-name="7 Deadly Sins (2019)" tvg-logo="https://image.tmdb.org/t/p/w600_and_h900_bestv2/36rKdmawU4E3K2m2k1DYLZz87Zf.jpg" group-title="Horror ",7 Deadly Sins (2019)
http://1tv41.icu:8080/movie/36471153/36471153/204405.mp4
#EXTINF:0 CUID="9649" tvg-name="11:11 (2011)" group-title="Horror ",11:11 (2011)
http://1tv41.icu:8080/movie/36471153/36471153/204406.mp4
#EXTINF:0 CUID="9650" tvg-name="30 Miles from Nowhere (2018)" tvg-logo="https://image.tmdb.org/t/p/w600_and_h900_bestv2/la033FX81LsiIId67AM5SEtVSXt.jpg" group-title="Horror ",30 Miles from Nowhere (2018)
http://as.45336544.xyz:8080/4kultra189/try628201y6y/106060
#EXTINF:0 CUID="9651" tvg-name="60 Seconds to Die (2017)" tvg-logo="https://image.tmdb.org/t/p/w600_and_h900_bestv2/5Flzesb27cBBIhqIpPzcmos5dHg.jpg" group-title="Horror ",60 Seconds to Die (2017)
http://1tv41.icu:8080/movie/36471153/36471153/204408.mp4
#EXTINF:0 CUID="8822" tvg-name="The Simpsons S35 E07" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E07
http://1tv41.icu:8080/series/36471153/36471153/214834.mkv
#EXTINF:0 CUID="8823" tvg-name="The Simpsons S35 E08" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E08
http://1tv41.icu:8080/series/36471153/36471153/214835.mkv
#EXTINF:0 CUID="8824" tvg-name="The Simpsons S35 E09" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E09
http://1tv41.icu:8080/series/36471153/36471153/214836.mkv
#EXTINF:0 CUID="8825" tvg-name="The Simpsons S35 E10" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E10
http://1tv41.icu:8080/series/36471153/36471153/214837.mkv
#EXTINF:0 CUID="8826" tvg-name="The Simpsons S35 E11" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E11
http://1tv41.icu:8080/series/36471153/36471153/214838.mkv
#EXTINF:0 CUID="8827" tvg-name="The Simpsons S35 E12" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E12
http://1tv41.icu:8080/series/36471153/36471153/214839.mkv
#EXTINF:0 CUID="8828" tvg-name="The Simpsons S35 E13" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E13
http://1tv41.icu:8080/series/36471153/36471153/214840.mkv
#EXTINF:0 CUID="8829" tvg-name="The Simpsons S35 E14" tvg-logo="https://image.tmdb.org/t/p/w780/vHqeLzYl3dEAutojCO26g0LIkom.jpg" group-title="Euphoria",The Simpsons S35 E14
http://1tv41.icu:8080/series/36471153/36471153/214841.mkv`;

    setM3uText(sampleData);
    toast.success("Sample playlist loaded!");
  };

  return (
    <div className="space-y-6">
      {/* Import from URL */}
      <div className="space-y-3">
        <Label htmlFor="m3u-url">Import from URL</Label>
        <div className="flex gap-2">
          <Input
            id="m3u-url"
            type="url"
            placeholder="https://example.com/playlist.m3u"
            value={m3uUrl}
            onChange={(e) => setM3uUrl(e.target.value)}
            className="bg-zinc-800 border-white/10"
          />
          <Button
            onClick={handleImportFromUrl}
            disabled={isImporting}
            className="bg-white text-black hover:bg-white/90"
          >
            <Link className="mr-2 h-4 w-4" />
            {isImporting ? "Importing..." : "Import"}
          </Button>
          <Button
            onClick={downloadM3U}
            variant="outline"
            disabled={isImporting}
            className="border-white/20 hover:bg-white/10"
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-white/50 text-sm">
          Pre-filled with your configured M3U URL
        </p>
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-white/10" />
        </div>
        <div className="relative flex justify-center">
          <span className="bg-zinc-900 px-2 text-white/60">OR</span>
        </div>
      </div>

      {/* Import from Text */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label htmlFor="m3u-text">Paste M3U Content</Label>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLoadSample}
            className="h-6 text-xs text-white/60 hover:text-white"
          >
            <FileText className="mr-1 h-3 w-3" />
            Load Sample Data
          </Button>
        </div>
        <Textarea
          id="m3u-text"
          placeholder="#EXTM3U&#10;#EXTINF:-1 tvg-logo=&quot;logo.png&quot; group-title=&quot;Movies&quot;,Channel Name&#10;http://example.com/stream"
          value={m3uText}
          onChange={(e) => setM3uText(e.target.value)}
          rows={8}
          className="bg-zinc-800 border-white/10 font-mono text-sm"
        />
        <Button
          onClick={handleImportFromText}
          disabled={isImporting}
          className="w-full bg-white text-black hover:bg-white/90"
        >
          <Upload className="mr-2 h-4 w-4" />
          {isImporting ? "Importing..." : "Import M3U Content"}
        </Button>
      </div>

      <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
        <p className="text-blue-400 text-sm">
          <strong>📺 How it works:</strong> Paste your M3U playlist content or use the URL above. 
          The app will automatically categorize channels into Movies, Series, and Live TV, 
          then fetch posters from TMDB.
        </p>
      </div>
    </div>
  );
}